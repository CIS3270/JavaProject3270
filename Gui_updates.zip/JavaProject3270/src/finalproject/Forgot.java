package finalproject;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import com.jgoodies.forms.factories.DefaultComponentFactory;

public class Forgot extends JFrame{
	private JTextField textField;
	
	//gui for when user wants to retrieve password
	

	
	Forgot(){
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter User Name");
		lblNewLabel.setBounds(87, 75, 105, 31);
		getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(189, 80, 86, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JButton submit = new JButton("Submit");
		submit.setBounds(151, 117, 89, 23);
		getContentPane().add(submit);
		
		JLabel title = new JLabel("Forgot Password?");
		title.setBounds(10, 0, 105, 31);
		getContentPane().add(title);
		
		//make submit button retrieve security question from database
		Action action = new Action();
		submit.addActionListener(action);
		
	}
}

 class Action implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	
		
	}
	
}

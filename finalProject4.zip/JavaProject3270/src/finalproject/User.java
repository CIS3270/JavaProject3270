package finalproject;

public class User {
	
	//class variables
	
	private String firstName;
	private String lastName;
	private String address;
	private int zipCode;
	private String state;
	private String userName;
	private String password;
	private String email;
	private int ssn;
	private String securityQuestion;
	private String securityAnswer;
	
	//constructors
	
	User(){
	}
	
	User (String firstName, String lastName, String address, int zipCode, String state){
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.zipCode = zipCode;
		this.state = state;
	
	}
	
	//class methods
	
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	public void setAddress(String address){
		this.address = address;
	}
	public void setZip (int zipCode){
		this.zipCode = zipCode;
	}
	public void setState (String state){
		this.state = state;
	}
	public void setEmail (String email){
		this.email = email;
	}
	public void setSSN (int ssn){
		this.ssn = ssn;
	}
	
	public void setUserName (String userName){
		this.userName = userName;
	}
	
	public  void setPassword (String password){
		this.password = password;
	}
	
	public String getUserName(){
		return userName;
	}
	
	public String getPassword(){
		return password;
	}
	
	public void setSecurityQuestion (String securityQuestion){
		this.securityQuestion = securityQuestion;
	}
	
	public void setAnswer (String answer){
		securityAnswer = answer;
	}
	
	public String toString(){
		return null;
		
	}
	
	
	
	
	

}
